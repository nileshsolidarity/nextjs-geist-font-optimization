(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_7e8aa2c7._.js",
  "static/chunks/node_modules_2d615e05._.js"
],
    source: "dynamic"
});
